import math
from heapq import heappush, heappop

def a_star_path(start, goal, num_targets, obstacles, formation_radius=0, vehicle_radius=0):
    """
    使用A*算法生成路径，并采样中间目标点，同时要求路径点与障碍物的安全距离大于
    障碍物半径 + 小车集群半径 + 小车自身半径。

    参数：
      start (tuple): 起始点坐标 (x, y)
      goal (tuple): 目标点坐标 (x, y)
      num_targets (int): 需要生成的中间目标个数
      obstacles (list): 障碍物列表，每个障碍物为三元组 (x, y, r)
      formation_radius (float): 小车集群半径
      vehicle_radius (float): 小车自身半径（默认 0）

    返回：
      list: 中间目标点列表，每个点为 (x, y)
    """
    grid_size = 1
    # 将连续坐标转换为网格坐标
    start_grid = (int(start[0] // grid_size), int(start[1] // grid_size))
    goal_grid  = (int(goal[0]  // grid_size), int(goal[1]  // grid_size))
    
    # 检查起始点与目标点是否在有效区域内（此处区域限定在 [0,20]×[0,20]）
    if not (0 <= start_grid[0] <= 20 and 0 <= start_grid[1] <= 20):
        return []
    if not (0 <= goal_grid[0]  <= 20 and 0 <= goal_grid[1]  <= 20):
        return []
    
    # 在网格中使用A*算法搜索路径
    path_grid = a_star(start_grid, goal_grid, obstacles, formation_radius, vehicle_radius)
    if not path_grid:
        return []
    
    # 将网格路径转换为连续坐标（网格中心）
    path_continuous = [(x + 0.5, y + 0.5) for (x, y) in path_grid]
    
    # 对连续路径进行均匀采样，生成中间目标点
    sampled_targets = sample_path(path_continuous, num_targets)
    return sampled_targets

def a_star(start, goal, obstacles, formation_radius, vehicle_radius):
    """
    A* 算法实现，在网格中搜索路径，要求路径点与障碍物保持安全距离。

    参数：
      start (tuple): 起始网格坐标 (x, y)
      goal (tuple): 目标网格坐标 (x, y)
      obstacles (list): 障碍物列表，每个障碍物为三元组 (x, y, r)
      formation_radius (float): 小车集群半径
      vehicle_radius (float): 小车自身半径

    返回：
      list: 路径（网格坐标列表）
    """
    open_heap = []
    heappush(open_heap, (0, start[0], start[1]))
    came_from = {}
    g_score = {start: 0}
    f_score = {start: heuristic(start, goal)}
    closed_set = set()

    while open_heap:
        current_f, cx, cy = heappop(open_heap)
        current = (cx, cy)
        
        if current == goal:
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.append(start)
            path.reverse()
            return path
        
        closed_set.add(current)
        # 遍历8个邻居（包括对角方向）
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                if dx == 0 and dy == 0:
                    continue
                neighbor = (cx + dx, cy + dy)
                if not (0 <= neighbor[0] <= 20 and 0 <= neighbor[1] <= 20):
                    continue
                if is_blocked(neighbor[0], neighbor[1], obstacles, formation_radius, vehicle_radius):
                    continue
                move_cost = 1 if (dx == 0 or dy == 0) else math.sqrt(2)
                tentative_g = g_score.get(current, float('inf')) + move_cost
                if neighbor in closed_set and tentative_g >= g_score.get(neighbor, float('inf')):
                    continue
                if tentative_g < g_score.get(neighbor, float('inf')):
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f = tentative_g + heuristic(neighbor, goal)
                    heappush(open_heap, (f, neighbor[0], neighbor[1]))
                    f_score[neighbor] = f
    return []

def heuristic(a, b):
    """启发式函数，返回两点间的欧几里得距离。"""
    return math.hypot(a[0] - b[0], a[1] - b[1])

def is_blocked(x, y, obstacles, formation_radius, vehicle_radius):
    """
    检查网格坐标 (x, y) 是否被障碍物阻挡，
    要求网格中心到障碍物中心的距离大于 (障碍物半径 + formation_radius + vehicle_radius)。
    
    参数：
      x, y: 网格坐标（整数）
      obstacles (list): 每个障碍物为 (ox, oy, r)
      formation_radius (float): 小车集群半径
      vehicle_radius (float): 小车自身半径
    
    返回：
      bool: 如果被阻挡返回 True，否则返回 False
    """
    cx, cy = x + 0.5, y + 0.5
    for obs in obstacles:
        ox, oy, r = obs
        margin = r + formation_radius*1.5 + vehicle_radius
        dx = cx - ox
        dy = cy - oy
        if dx**2 + dy**2 <= margin**2:
            return True
    return False

def sample_path(path, num_targets):
    """
    对连续路径进行采样，生成指定数量的中间目标点。

    参数：
      path (list): 连续路径点列表，每个点为 (x, y)
      num_targets (int): 需要生成的中间目标点个数

    返回：
      list: 采样后的中间目标点列表
    """
    if len(path) < 2 or num_targets <= 0:
        return []
    # 计算路径累积距离
    cumulative = [0.0]
    for i in range(1, len(path)):
        dx = path[i][0] - path[i-1][0]
        dy = path[i][1] - path[i-1][1]
        cumulative.append(cumulative[-1] + math.hypot(dx, dy))
    total = cumulative[-1]
    if total == 0:
        return []
    interval = total / (num_targets + 1)
    targets = []
    current_dist = interval
    current_seg = 0
    while len(targets) < num_targets and current_dist < total:
        while (current_seg < len(cumulative)-1 and cumulative[current_seg+1] < current_dist):
            current_seg += 1
        seg_start = cumulative[current_seg]
        seg_end = cumulative[current_seg+1]
        seg_length = seg_end - seg_start
        if seg_length == 0:
            continue
        t = (current_dist - seg_start) / seg_length
        x = path[current_seg][0] + t*(path[current_seg+1][0] - path[current_seg][0])
        y = path[current_seg][1] + t*(path[current_seg+1][1] - path[current_seg][1])
        targets.append((x, y))
        current_dist += interval
    return targets[:num_targets]
